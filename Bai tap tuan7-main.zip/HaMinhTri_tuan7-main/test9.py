import numpy as np
freetuts_visitors = np.array([3776, 3112, 3476, 3319, 3559, 50293, 30432]) # 2 giá trị cuối lệch xa so với các giá trị trong dãy
print("Mean = : ", np.mean(freetuts_visitors))
print("Median = : ", np.median(freetuts_visitors))