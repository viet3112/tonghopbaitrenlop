import numpy as np
p = np.random.permutation(10)
print(p)