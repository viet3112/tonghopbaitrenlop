import numpy as np

x = [1, 2, 3, 4, 5]
print("Mean x =", np.mean(x))