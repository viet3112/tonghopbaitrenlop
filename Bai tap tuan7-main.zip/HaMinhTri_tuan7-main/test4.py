import numpy as np
print("mean a = ", np.mean(a, dtype=np.float64))