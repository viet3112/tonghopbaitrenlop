import numpy as np

e = np.random
e.seed(10)

print("e rand: ", e.rand())