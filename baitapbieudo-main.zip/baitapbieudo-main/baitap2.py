from matplotlib import pyplot
years = [2013,2014,2015,2016,2017,2018,2019,2020]
companyA = [41596,46000,48510,53310,57200,56000,63316,69741]

pyplot.plot(years, companyA,)
pyplot.show()