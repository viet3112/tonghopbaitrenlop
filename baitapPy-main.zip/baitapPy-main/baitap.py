x = input()
y = input()

if a > b:
    print("x lon hon y")
else:
    print("x be hon y")